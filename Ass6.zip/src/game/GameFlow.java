//id:213214026
package game;

import biuoop.GUI;
import objects.Counter;
import screens.GameOver;
import screens.KeyPressStoppableAnimation;
import screens.LevelInformation;

import java.util.List;

/**
 * controls the game flow.
 * */
public class GameFlow {
    private GUI gui;
    private AnimationRunner runner;
    private boolean hasWon;
    /**
     * creates a game flow object.
     * @param gui the interface
     * @param runner animation runner
     * */
    public GameFlow(GUI gui, AnimationRunner runner) {
        this.gui = gui;
        this.runner = runner;
        hasWon = true;
    }
    /**
     * runs the levels.
     * @param levels the lise of levels
     * */
    public void runLevels(List<LevelInformation> levels) {
        Counter score = new Counter();
        for (LevelInformation levelInfo:levels) {
            GameLevel level = new GameLevel(levelInfo, score, this.gui);
            level.initialize();
            while (level.getRemainingBalls() > 0 && level.getRemainingBlocks() > 0) {
                level.run();
                if (level.getRemainingBlocks() == 0) {
                    break;
                }
            }
            if (level.getRemainingBalls() == 0) {
                hasWon = false;
                break;
            }
        }
        runner.run(new KeyPressStoppableAnimation(gui.getKeyboardSensor(), gui.getKeyboardSensor().SPACE_KEY,
                new GameOver(hasWon, score.getValue())));
        gui.close();
    }
}
