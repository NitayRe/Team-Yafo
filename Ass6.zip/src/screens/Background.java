//id:213214026
package screens;
import biuoop.DrawSurface;
import objects.Sprite;
/**
 * Background abstract class.
 * */
public class Background implements Sprite {
    @Override
    public void drawOn(DrawSurface d) {
        return;
    }

    @Override
    public void timePassed() {
        return;
    }
}
